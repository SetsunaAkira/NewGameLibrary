#include "fileSystem.h"

bool fileSystem::Initialize(Engine * engine)
{
	m_engine = engine;
	return false;
}

void fileSystem::Update()
{
}

void fileSystem::Shutdown()
{
}
