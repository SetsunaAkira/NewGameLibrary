#include "enemymissile.h"


void EnemyMissile::Create(const Vector2D & position, const Vector2D & direction, float speed)
{
	position;
	direction;
	speed;
}

void EnemyMissile::Update()
{
}

void EnemyMissile::OnEvent(const Event & event)
{
	event;
}
