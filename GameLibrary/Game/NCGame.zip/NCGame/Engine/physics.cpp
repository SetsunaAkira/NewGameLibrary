#include "physics.h"

bool Physics::Initialize(Engine * engine)
{
	m_engine = engine;
	return false;
}

void Physics::Shutdown()
{
}

void Physics::Update()
{
}
